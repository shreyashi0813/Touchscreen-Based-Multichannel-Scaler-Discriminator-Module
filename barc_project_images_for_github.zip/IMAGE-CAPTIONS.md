# Image captions

These project-specific images were extracted from the internship report. Review them for permission/confidentiality before publishing. Do not upload certificate or personal-information pages from the report.

- `media/arduino-mega-2560.png` — Arduino Mega 2560 development board.
- `media/wt32-sc01-board.png` — WT32-SC01 ESP32 touchscreen development board.
- `media/arduino-mega-test-setup.jpg` — Arduino Mega scaler test setup with signal generator.
- `media/wt32-main-screen.jpg` — WT32-SC01 scaler main screen.
- `media/wt32-setup-screen.jpg` — WT32-SC01 time and scale setup screen.
- `media/wt32-live-graph.jpg` — WT32-SC01 real-time graph screen.
- `media/analog-front-end-schematic.png` — Analog front-end schematic screenshot from report.
- `media/pcb-layout-view.png` — KiCad PCB layout screenshot from report.
